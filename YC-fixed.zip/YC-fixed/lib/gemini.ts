import { GoogleGenAI, type GenerateContentParameters, type GenerateContentResponse } from '@google/genai';
import { safeResponseUnavailable, serviceUnavailable } from './messages';
import { beforeDeadline } from './deadline';
import { buildContents, systemInstruction } from './prompt';

const MODEL = 'gemini-3.5-flash';
const MAX_ATTEMPTS = 3;
const ATTEMPT_TIMEOUT_MS = 10_000;
const MIN_RETRY_BUDGET_MS = 1_000;

type GeminiDependencies = {
  generateContent: (params: GenerateContentParameters) => Promise<GenerateContentResponse>;
  now: () => number;
  sleep: (ms: number) => Promise<void>;
  random: () => number;
};

const defaults: GeminiDependencies = {
  generateContent: params => {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) throw new Error('configuration');
    return new GoogleGenAI({ apiKey }).models.generateContent(params);
  },
  now: () => Date.now(),
  sleep: ms => new Promise(resolve => setTimeout(resolve, ms)),
  random: () => Math.random(),
};

function httpStatus(error: unknown): number | null {
  const status = typeof error === 'object' && error !== null && 'status' in error ? error.status : null;
  return typeof status === 'number' ? status : null;
}

function isTransient(error: unknown): boolean {
  const status = httpStatus(error);
  if (status !== null) return [408, 429, 500, 502, 503, 504].includes(status);
  return error instanceof Error && (
    error.name === 'TimeoutError' || error.name === 'AbortError' || error.message === 'deadline_exceeded'
  );
}

export function extractReply(response: GenerateContentResponse): string {
  const candidate = response.candidates?.[0];
  if (response.promptFeedback?.blockReason || candidate?.finishReason === 'SAFETY') return safeResponseUnavailable;
  if (candidate?.finishReason !== 'STOP') return serviceUnavailable;
  const text = candidate.content?.parts?.filter(p => !p.thought).map(p => p.text ?? '').join('').trim();
  return text && text.length <= 4500 ? text : serviceUnavailable;
}

export async function askGemini(
  faq: string, question: string, deadline: number, eventId: string,
  deps: GeminiDependencies = defaults,
): Promise<string> {
  const started = deps.now();
  let result: GenerateContentResponse | undefined;
  let errorType: string | null = null;
  let attempts = 0;
  try {
    const contents = buildContents(faq, question);
    for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
      const remaining = deadline - deps.now();
      if (remaining <= 0) throw new Error('deadline_exceeded');
      attempts = attempt;
      const timeout = Math.min(ATTEMPT_TIMEOUT_MS, remaining);
      const attemptDeadline = Math.min(deadline, deps.now() + timeout);
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), timeout);
      let failure: unknown;
      try {
        result = await beforeDeadline(deps.generateContent({
          model: MODEL, contents,
          config: {
            systemInstruction,
            maxOutputTokens: 2048,
            abortSignal: controller.signal,
            // This loop owns retries so SDK backoff cannot consume the LINE reply budget.
            httpOptions: { timeout, retryOptions: { attempts: 1 } },
          },
        }), attemptDeadline);
        return extractReply(result);
      } catch (error) {
        failure = error;
      } finally {
        clearTimeout(timer);
        controller.abort();
      }

      const delayMs = 500 * 2 ** (attempt - 1) + Math.floor(deps.random() * 250);
      if (!isTransient(failure) || attempt === MAX_ATTEMPTS ||
          deadline - deps.now() < delayMs + MIN_RETRY_BUDGET_MS) throw failure;
      console.warn('gemini_request_retry', {
        eventId, model: MODEL, attempt, httpStatus: httpStatus(failure), delayMs,
      });
      await beforeDeadline(deps.sleep(delayMs), deadline);
    }
    return serviceUnavailable;
  } catch (error) {
    errorType = error instanceof Error ? error.name : 'UnknownError';
    console.error('gemini_request_failed', {
      eventId, model: MODEL, attempts, httpStatus: httpStatus(error), errorType,
    });
    return serviceUnavailable;
  } finally {
    console.info('gemini_request', {
      eventId, model: MODEL, attempts, durationMs: deps.now() - started,
      finishReason: result?.candidates?.[0]?.finishReason ?? null,
      thoughtsTokenCount: result?.usageMetadata?.thoughtsTokenCount ?? null,
      candidatesTokenCount: result?.usageMetadata?.candidatesTokenCount ?? null, errorType,
    });
  }
}
